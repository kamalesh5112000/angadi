<?php

include("smsalert/classes/smsalert.php");


$apikey='5eb919d6b76df';     // write your apikey in between ''
$senderid='ANGADI';	// write your senderid in between ''
$route='transactional';      // write your route in between ''
$username='angadi2020'; // write your username in between ''
$pass='Angadi#sms#2020';	// write your pass in between ''
$smsalert = (new Smsalert()) 		
	   ->authWithUserIdPwd($username,$pass)
	   ->setRoute($route)
	   ->setSender($senderid);

$payload = file_get_contents('php://input');

$array=json_decode($payload,1);

$order_id=$array['id'];
$status=$array['status'];
if($status=='driver-assigned')
{
$billing=$array['billing'];
$customer_phone=$billing['phone'];
$metadata=$array['meta_data'];
$total=$array['total'];
$order_status=$array['status'];
$customer_name=$billing['first_name'];
 $customer_address=$billing['address_1'].', '.$billing['address_2'].', '.$billing['city'].'. '.$billing['postcode'];
$zip=$billing['postcode'];
//$customer_address=$billing['address_1'];
foreach($metadata as $md){
    if($md['key']=='store_phone'){
        $store_phone=$md['value'];
    }elseif($md['key']=='store_name'){
        $store_name=$md['value'];
    }elseif($md['key']=='store_telegram'){
        $store_telegram=$md['value'];
    }elseif($md['key']=='store_address'){
        $store_address=$md['value'];
    }elseif($md['key']=='store_email'){
        $store_email=$md['value'];
    }elseif($md['key']=='_billing_telegram'){
        $customer_telegram=$md['value'];
    }
    elseif($md['key']=='ddwc_driver_phone'){
        $driver_phone=$md['value'];
    }
    elseif($md['key']=='ddwc_driver_name'){
        $driver_name=$md['value'];
    } elseif($md['key']=='_wcfmmp_user_location_lat'){
        $userlat=$md['value'];
    }elseif($md['key']=='_wcfmmp_user_location_lng'){
        $userlng=$md['value'];
    }
    elseif($md['key']=='store_lat'){
        $storelat=$md['value'];
    }
     elseif($md['key']=='store_lng'){
        $storelng=$md['value'];
    }
    
}

$items=$array['line_items'];


$quan=0;
foreach($items as $value){
  $quan+=$value['quantity'];
  
}
function distance($lat1, $lon1, $lat2, $lon2) {
  if (($lat1 == $lat2) && ($lon1 == $lon2)) {
    return 0;
  }
  else {
    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
      return ceil($miles * 1.609344)*5; 
  }
}


$rate=distance($userlat, $userlng, $storelat, $storelng);
   
//======== for store sms ================
$numbers=$store_phone;
$messages="Dear Store, the order #$order_id from $customer_name($customer_address) will be delivered by our delivery person $driver_name. In case of any emergencies contact $driver_phone. Thank You!";
$result = $smsalert->send($numbers,$messages);

$numberd=$driver_phone;
$messaged="Dear $driver_name, your request to deliver the order #$order_id has been accepted. The Drivers Dashboard will contain the details of the order, please update the status of the order after delivery. Please collect your delivery charge of Rs.$rate from the customer. Thank You!";
$result = $smsalert->send($numberd,$messaged);

//======== for customer sms ================
$numberc=$customer_phone;
$messagec="Dear Customer, your order #$order_id from $store_name($store_address) will be delivered by our delivery person $driver_name. In case of any emergencies contact $driver_phone. Please pay the delivery charges of Rs.$rate to the delivery person.Thank You!";
 $result = $smsalert->send($numberc,$messagec);
}