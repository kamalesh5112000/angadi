<?php
/*
Plugin Name: Single Store Order
Plugin URI: 
Description: Restricts order from multiple vendors in a single checkout. Allows orders from a single vendor at a time.
Author: Angadi
Author URI: http://angadi.co.in
Version: 1.0


*/


add_action( 'woocommerce_add_to_cart_validation', function( $is_allow, $product_id, $quantity ) {
	$product = get_post( $product_id );
	$product_author = $product->post_author;

	//Iterating through each cart item
	foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
		$cart_product_id = $cart_item['product_id'];
		$cart_product = get_post( $cart_product_id );
		$cart_product_author = $cart_product->post_author;
		if( $cart_product_author != $product_author ) {
			$is_allow = false;
			break;
		}
	}

	if( !$is_allow ){
		// We display an error message
		wc_clear_notices();
		wc_add_notice( __( "You can only place orders from a single store at once. First checkout with those items and then purchase other items!", "wcfm-ecogear" ), 'error' );
	}
	
	return $is_allow;
}, 50, 3 );
